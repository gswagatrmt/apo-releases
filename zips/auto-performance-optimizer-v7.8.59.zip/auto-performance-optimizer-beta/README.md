# Auto Performance Optimizer (APO)

A WordPress performance plugin built around one promise: **make Core Web Vitals pass without ever breaking the site — and keep the optimizations even if the plugin is deleted.**

APO does the CWV-critical work of WP Rocket, Perfmatters, Autoptimize and Seraphinite, but writes its fixes to a **standalone must-use plugin** that survives uninstall. It is designed for agencies running many client sites where stability matters more than a leaderboard score.

---

## Table of contents

1. [The 60-second quick start](#the-60-second-quick-start)
2. [The four tiers](#the-four-tiers)
3. [Targeted quick-fixes](#targeted-quick-fixes)
4. [The Asset Manager](#the-asset-manager)
5. [Database cleanup](#database-cleanup)
6. [How persistence works (the USP)](#how-persistence-works-the-usp)
7. [Reading your results correctly](#reading-your-results-correctly)
8. [If something looks wrong](#if-something-looks-wrong)
9. [Safety model](#safety-model)
10. [FAQ](#faq)

---

## The 60-second quick start

1. Install and activate **Auto Performance Optimizer**.
2. Open the plugin → the **🧭 Advisor** tab.
3. APO has already scanned your site and recommends a tier. Click **Apply Balanced** (the usual recommendation).
4. **Clear any cache** (host cache, CDN, cache plugin).
5. Re-test in [PageSpeed Insights](https://pagespeed.web.dev).
6. Click through the site — menus, sliders, forms, checkout — to confirm everything works.

That's it. If anything looks off, the **History** tab reverts it in one click.

> **Test on production, not staging.** A staging site with no CDN is bandwidth-starved and will report much worse LCP/FCP than reality. See [Reading your results correctly](#reading-your-results-correctly).

---

## The four tiers

APO ships four one-click presets on the Advisor. They're cumulative — each includes everything below it. The **applied tier shows a blue ✓ APPLIED badge**.

| Tier | What it turns on | Caching? | Risk | Use when |
|------|------------------|----------|------|----------|
| 🟢 **Basic** | CLS fixes (image + icon-SVG dimensions, slider reserve), WebP, LCP preload + `fetchpriority`, lazy-load, preconnect/DNS-prefetch. **No** Delay-JS, **no** CSS deferral, **no** font changes, **no** caching. | No | **Zero** — nothing changes how the site looks or behaves | You want guaranteed-safe wins and nothing else |
| ⚡ **Balanced** | Everything in Basic **+** Delay-JS, critical-CSS + defer render-blocking CSS, iframe facades, HTML minify, heartbeat throttle, and `font-display:optional` (zero font-swap CLS). | **No** | Low — test menus/sliders/forms | **Most sites.** Full performance, safe alongside WP Engine / Kinsta / a cache plugin |
| 🚀 **Maximum** | Everything in Balanced **+** APO's own full-page cache (drop-in) + browser-cache headers. | **Yes** | Medium — don't double-cache | Hosts with **no** server/edge cache |
| 🧪 **Experimental** | Everything in Maximum **+** remove-unused-CSS, FontAwesome de-dupe/inline, aggressive byte-shaving. | Yes | Higher — test carefully | You've validated Maximum and want the last bytes |

### Which should I pick?

- **Behind a CDN or managed host (WP Engine, Kinsta, SiteGround) or running a cache plugin?** → **Balanced.** It gives the full performance stack without a second cache layer.
- **Cheap/unmanaged host with no caching?** → **Maximum.**
- **Never pick Basic for speed** — it's strictly slower than Balanced with identical CLS. Basic exists only for "change nothing visual" situations.
- **Experimental** is opt-in territory: apply it, then check icons, fonts and any element that looked styled before.

The Advisor auto-detects your cache layer and highlights the right recommendation for you.

---

## Targeted quick-fixes

Below the tier cards, the Advisor has a **🎯 Targeted quick-fixes** row — individual high-impact levers you can flip *without* changing your whole preset. Each shows a live ON/OFF state and is reversible from History.

| Quick-fix | What it does | Watch for |
|-----------|--------------|-----------|
| **🎯 Optimize FontAwesome** | De-dupes multiple FontAwesome stylesheets, inlines the kept one with `font-display:swap` (removes the render-blocking request), and drops preloads for unused icon weights (the ~350 KB `fa-light`/`fa-regular` waste). | Check your icons still render |
| **✂️ Remove unused CSS** | With critical CSS active, drops the covered theme/layout stylesheets entirely — cuts transfer bytes, not just render-blocking. | Check nothing looks unstyled |
| **🔤 Font-display: optional** | Forces Google Fonts to `font-display:optional` → zero font-swap CLS. | On a slow first load the fallback font may show (see below) |

> **These are already ON in Balanced and above** (except remove-unused-CSS, which is Experimental-only). The quick-fixes let you toggle them individually, e.g. turn FontAwesome optimization on while staying on Basic.

### About `font-display: optional`

This is the setting that guarantees **zero font-swap layout shift**. The trade-off:

- **On production behind a CDN:** fonts load in ~50–100 ms, so `optional` shows your **brand font AND** gives CLS 0. Invisible win.
- **On a slow first load (e.g. no-CDN staging):** the browser uses a system fallback for that first paint and shows the brand font on the next cached visit.

If a client insists the brand font must appear even on a cold load and will accept a little CLS, turn this quick-fix **off**.

---

## The Asset Manager

**🧩 Assets tab** — the equivalent of Perfmatters' Script Manager. Use it for surgical, per-handle control:

1. Click **Scan homepage** (or any URL) to list every enqueued script and stylesheet.
2. For anything you don't need on that page, choose **Disable everywhere** or **Disable on this URL only**.
3. Save. The rules are written into the mu-plugin and apply to logged-out visitors.

**Common wins:**
- Disable **duplicate FontAwesome** stylesheets a theme + plugins each load.
- Load **Calendly / booking / chat widgets** only on the pages that use them (often 400 KB+ of CSS/JS saved elsewhere).
- Drop **contact-form or slider assets** on pages without those elements.

This is the safest way to cut third-party weight because *you* decide exactly what goes, page by page.

---

## Database cleanup

**🗄️ Cache tab → Database Cleanup** — remove the cruft WordPress accumulates:

- Post revisions, auto-drafts, trashed posts
- Spam and trashed comments
- Expired transients
- Orphaned metadata
- Optimize all tables (reclaim overhead)

Each task is opt-in with a live count, and **published content is never touched**. Still, **back up your database first** — deletions can't be undone.

---

## How persistence works (the USP)

This is what nothing else does. When you Apply, APO writes a self-contained file to:

```
wp-content/mu-plugins/apo-applied.php
```

Must-use plugins load automatically and **cannot be deactivated from the dashboard**. So:

- **Delete the Auto Performance Optimizer plugin** and roughly **90% of the optimizations keep working** — the mu-plugin stays.
- The critical CSS **self-heals**: its cache key includes a fingerprint of your stylesheets, so when you edit a page (and the CSS `?ver=` changes) it regenerates automatically — even after the main plugin is gone.
- It survives **theme switches** too.

To remove everything: **History → Revert**, or delete `wp-content/mu-plugins/apo-applied.php`.

If you want the fixes gone when you uninstall, untick **"persist on uninstall"** before deleting.

---

## Reading your results correctly

A few things that trip people up:

**The LCP line on a waterfall is a *time*, not a *position*.** Images sitting near the LCP marker are usually just downloading in the same window — they are not the LCP element. PageSpeed names the real LCP element in the "LCP breakdown" section.

**CLS on a no-CDN staging site is exaggerated.** Everything loads so slowly that late shifts (fonts, trickling images) get fully counted. The same site on production behind a CDN shows meaningfully lower CLS.

**Staging LCP/FCP is not your real number.** With no CDN, every asset crawls over a shared ~2 Mbps pipe, which structurally caps LCP/FCP around 4–5 s no matter how good the optimization is. The tell: **CLS and TBT (which don't depend on bandwidth) can be perfect while LCP/FCP look mediocre.** Always validate on **one production site behind your CDN** — that's the number clients see.

**Making a site faster can expose latent problems.** A faster first paint can reveal a font swap that was previously hidden behind a slow load. That's why Balanced bundles `font-display:optional` — so speeding things up doesn't re-introduce CLS.

---

## If something looks wrong

In order of ease:

1. **History → Revert.** Removes the mu-plugin instantly.
2. Toggle the specific quick-fix (FontAwesome / remove-unused-CSS / font-optional) back off from the Advisor.
3. Via FTP/file manager: delete `wp-content/mu-plugins/apo-applied.php`.
4. Kill switch: add to `wp-config.php`:
   ```php
   define('APO_APPLIED_DISABLE', true);
   ```
   This disables all applied fixes without any file access.
5. **Always clear your cache** after applying or reverting.

---

## Safety model

APO is built stability-first:

- **mu-plugin isolation** — WordPress loads must-use plugins in isolation; even a fatal error in the applied file can't lock you out of wp-admin.
- **Validated before write** — generated PHP is checked with `php -l` and token analysis; broken code is never written.
- **Atomic writes** — temp file → verify → rename. No partial files.
- **Fail-open everywhere** — every runtime hook and output buffer is wrapped in try/catch and returns the original output on any error.
- **Context guards** — fixes never run in admin, AJAX, REST, cron, CLI, XML-RPC, the customizer, or page builders.
- **One-click undo + backups** — every change is logged and reversible from History.
- **No metric gaming** — APO refuses decoy/cloaking tricks that fake scores. It ships an honest **DECOY detector** instead.

---

## FAQ

**Do I need this if my host already caches (WP Engine, Kinsta, etc.)?**
Yes — those handle page caching, but not CLS fixes, LCP preload, Delay-JS, critical CSS, image dimensions, or font handling. Use **Balanced** so APO doesn't add a second cache layer.

**Will it conflict with WP Rocket / LiteSpeed / Perfmatters?**
Run **Balanced** (no page cache) alongside another plugin's caching, and don't enable overlapping features in both. APO detects common cache plugins and adjusts its recommendation.

**Does aggregation/concatenation (combine CSS/JS) exist?**
No — deliberately. It's obsolete and often harmful on HTTP/2 (WP Rocket removed it too). APO relies on HTTP/2 multiplexing instead.

**My staging LCP is still 4–5 s after everything. Is the plugin working?**
Almost certainly yes — check CLS and TBT. If those are 0, the LCP/FCP number is your staging bandwidth, not the plugin. Test on production behind your CDN.

**What are the FontAwesome flags about?**
FontAwesome ships `@font-face` with no `font-display` and many themes load it 2–3 times. Turn on **Optimize FontAwesome** (or apply Experimental) to de-dupe, add `font-display:swap`, and drop unused weights.

**How do I remove everything?**
History → Revert, or delete `wp-content/mu-plugins/apo-applied.php`. Untick "persist on uninstall" first if you want deletion to clean up automatically.

---

*Auto Performance Optimizer — fast sites that stay fast, even after the plugin is gone.*
