<?php
if(true){
if ( ! function_exists( '_apo_build_critical' ) ) {
// ---- v6.81: DISK cache for the built critical CSS -------------------------------------------------
// Critical CSS was cached in a TRANSIENT only. On a host with a persistent object cache (WP Engine,
// Redis, Memcached) transients are EVICTABLE under memory pressure — and on eviction the next request
// re-runs _apo_build_critical(), which purges the site's entire CSS (645KB raw here) INSIDE the render.
// MEASURED consequence: PSI "Server responded slowly (652 ms)" / "Document request latency 550ms".
// A file survives object-cache eviction, so the expensive build happens once per (path,device,fingerprint)
// instead of whenever the cache feels like it. Transient stays as the fast L1; the file is L2.
// Keyed by the same string as the transient (which already includes the RUM measurement), so it
// self-invalidates on re-measure. Fail-safe: any I/O problem just means we fall back to rebuilding.
function _apo_cc_dir() {
  $b = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : ( rtrim(ABSPATH,'/') . '/wp-content' );
  return $b . '/apo-cache/cc';
}
function _apo_cc_file( $key ) {
  return _apo_cc_dir() . '/' . preg_replace('/[^a-z0-9_]/i','',(string)$key) . '.css';
}
function _apo_cc_file_get( $key ) {
  try {
    $f = _apo_cc_file($key);
    if ( ! is_file($f) ) { return false; }
    if ( (int) @filemtime($f) < time() - 604800 ) { @unlink($f); return false; }   // 7d hard TTL
    $s = @file_get_contents($f);
    return ( $s === false ) ? false : (string) $s;   // NB: '' is a VALID cached value (over-cap = don't rebuild)
  } catch ( \Throwable $e ) { return false; }
}
function _apo_cc_file_put( $key, $css ) {
  try {
    $d = _apo_cc_dir();
    if ( ! is_dir($d) ) {
      if ( ! @mkdir($d, 0755, true) && ! is_dir($d) ) { return false; }
      @file_put_contents( $d . '/index.php', '<?php // silence' );
      @file_put_contents( $d . '/.htaccess', "Deny from all\n" );
    }
    $f = _apo_cc_file($key);
    // temp + rename = atomic, so a concurrent request can never read a half-written file
    $t = $f . '.' . getmypid() . '.tmp';
    if ( @file_put_contents( $t, (string) $css, LOCK_EX ) === false ) { return false; }
    if ( ! @rename( $t, $f ) ) { @unlink($t); return false; }
    return true;
  } catch ( \Throwable $e ) { return false; }
}
function _apo_foldr_file( $key ) {
  return _apo_cc_dir() . '/' . preg_replace('/[^a-z0-9_]/i','',(string)$key) . '.fold';
}
function _apo_foldr_file_get( $key ) {
  // v6.226 — durable L2 for the BROWSER-MEASURED fold (apo_foldr_*). The measurement lives in a
  // transient, which is EVICTABLE on a Redis/Memcached host regardless of its 30-day TTL. When it is
  // evicted, the critical-CSS build loses the measurement and falls back to the HEURISTIC token slice —
  // a DIFFERENT (and on some folds incomplete) critical set. The page cache (often short-TTL) then
  // freezes that heuristic build and the fold shifts, until a visitor re-measures and it flips back.
  // That flip IS the "CLS returns after some hours, clears on cache-flush" cycle. A disk copy makes the
  // measurement survive eviction, so the critical CSS stays the stable measured build. Additive-only:
  // the measurement is only ever UNIONED into critical (keeps MORE CSS), so restoring it can never drop
  // a rule or change layout — it strictly moves toward the already-verified CLS-0 measured build.
  try {
    $f = _apo_foldr_file($key);
    if ( ! is_file($f) ) { return false; }
    if ( (int) @filemtime($f) < time() - 2592000 ) { @unlink($f); return false; }   // 30d TTL (matches the transient)
    $s = @file_get_contents($f);
    if ( ! is_string($s) || $s === '' ) { return false; }
    $d = @unserialize($s);
    return ( is_array($d) && ! empty($d['cls']) ) ? $d : false;
  } catch ( \Throwable $e ) { return false; }
}
function _apo_foldr_file_put( $key, $data ) {
  try {
    if ( ! is_array($data) || empty($data['cls']) ) { return false; }
    $d = _apo_cc_dir();
    if ( ! is_dir($d) ) {
      if ( ! @mkdir($d, 0755, true) && ! is_dir($d) ) { return false; }
      @file_put_contents( $d . '/index.php', '<?php // silence' );
      @file_put_contents( $d . '/.htaccess', "Deny from all\n" );
    }
    $f = _apo_foldr_file($key);
    $t = $f . '.' . getmypid() . '.tmp';   // temp + atomic rename (a concurrent read never sees a half-written file)
    if ( @file_put_contents( $t, serialize($data), LOCK_EX ) === false ) { return false; }
    if ( ! @rename( $t, $f ) ) { @unlink($t); return false; }
    return true;
  } catch ( \Throwable $e ) { return false; }
}
function _apo_cc_tokens( $html ) {
  $cls=array(); $ids=array();
  if ( preg_match_all('/\sclass\s*=\s*("|\')(.*?)\1/is',$html,$m) ) { foreach($m[2] as $c){ foreach(preg_split('/\s+/',trim($c)) as $x){ if($x!=='')$cls[strtolower($x)]=1; } } }
  if ( preg_match_all('/\sid\s*=\s*("|\')(.*?)\1/is',$html,$m) ) { foreach($m[2] as $x){ $x=trim($x); if($x!=='')$ids[strtolower($x)]=1; } }
  return array('cls'=>$cls,'ids'=>$ids);
}
function _apo_cc_header_tokens( $html ) {
  // v6.148 — Collect the class/id tokens of the SITE HEADER region so critical CSS ALWAYS covers the
  // header, no matter what the measured/PRECISE fold captured. WHY: the header is above the fold on its
  // target device, but PRECISE mode builds critical from the RUM-measured fold, which EXCLUDES elements
  // hidden on the measuring device. A DESKTOP-ONLY header top-bar (columns marked
  // elementor-hidden-tablet/elementor-hidden-mobile — e.g. a phone/email strip + "Get a Quote" buttons)
  // is therefore dropped from a mobile-measured critical, and since ONE critical CSS is served to every
  // device it renders UNSTYLED on desktop cold loads: the <ul> falls back to display:list-item (vertical
  // bullet list), then collapses to the styled horizontal row when the async CSS lands = a large layout
  // shift (measured CLS 0.73 on a heavy-fold test site). Unioning these tokens in is strictly ADDITIVE (can only
  // add rules to critical, never remove) so it cannot break layout. Universal: keys off the <header>
  // element / Elementor header-location template, never a site name or custom class.
  try {
    if ( ! is_string($html) || $html === '' ) return array('cls'=>array(),'ids'=>array());
    $region = '';
    // 1) Every <header>…</header> block (theme header + most Elementor header templates render inside it).
    if ( preg_match_all('#<header\b[^>]*>.*?</header>#is', $html, $hm) ) { $region = implode(' ', $hm[0]); }
    // 2) Elementor header-location container when it is NOT wrapped in a <header> tag. Bounded slice
    //    (header templates are small; the cap keeps this from swallowing page content).
    if ( $region === '' && preg_match('#<div\b[^>]*\bdata-elementor-type\s*=\s*("|\')header\1[^>]*>#i', $html, $em, PREG_OFFSET_CAPTURE) ) {
      $region = substr($html, $em[0][1], 40000);
    }
    // 3) Fallback: no recognisable header markup → take the top slice of the body (the header sits there).
    if ( $region === '' && preg_match('/<body\b[^>]*>/i', $html, $bm, PREG_OFFSET_CAPTURE) ) {
      $region = substr($html, $bm[0][1] + strlen($bm[0][0]), 24000);
    }
    if ( $region === '' ) return array('cls'=>array(),'ids'=>array());
    // Inline <script>/<template> carry class names in JSON (Elementor data-settings) that aren't DOM.
    $region = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $region);
    $region = preg_replace('#<template\b[^>]*>.*?</template>#is', '', $region);
    if ( ! is_string($region) || $region === '' ) return array('cls'=>array(),'ids'=>array());
    return _apo_cc_tokens( $region );
  } catch ( \Throwable $e ) { return array('cls'=>array(),'ids'=>array()); }
}
function _apo_cc_fold( $html ) {
  // THE FIX. Critical CSS must cover the ABOVE-THE-FOLD subset — but tokens were being collected from
  // the WHOLE page, so every footer/mega-menu/blog-grid class kept its rules and the "critical" set
  // came back at 351KB (a near-copy of the stylesheets). Return a SLICE: the document prefix (<html>,
  // <head>, <body> open tag — which carry elementor-kit-N / page / theme classes a LOT of CSS keys
  // off) plus roughly the first fold's worth of body markup.
  // Truncation can only ADD junk tokens or REMOVE below-fold ones — it can never drop a token that IS
  // in the fold. So a bad cut costs a little extra CSS, never missing fold CSS. Right failure direction.
  // FAIL-OPEN: anything unexpected returns $html unchanged (= today's whole-page behaviour).
  try {
    if ( defined('APO_CC_FOLD') && ! APO_CC_FOLD ) { return $html; }
    if ( ! preg_match('/<body\b[^>]*>/i',$html,$bm,PREG_OFFSET_CAPTURE) ) { return $html; }
    $bstart = $bm[0][1] + strlen($bm[0][0]);
    $prefix = substr($html,0,$bstart);     // MUST keep <html class> + <body class>
    $body   = substr($html,$bstart);
    // Inline <script>/<template> carry class names in JSON (Elementor data-settings,
    // elementorFrontendConfig) that are NOT rendered DOM. They alone inflate the token set with
    // hundreds of below-fold widget classes.
    $body = preg_replace('#<script\b[^>]*>.*?</script>#is','',$body);
    $body = preg_replace('#<template\b[^>]*>.*?</template>#is','',$body);
    // STRIP DROPDOWN SUB-MENUS from the fold scan. On a mega-menu site the header carries hundreds of
    // nested <ul class="sub-menu"> items — display:none dropdown panels that are NEVER in the initial
    // viewport. Left in the slice they dominate the token scan, so the "critical" CSS balloons past the
    // 100KB cap and gets rejected -> no deferral -> bad LCP (measured live: 264KB -> rejected). We empty
    // the CONTENTS of each sub-menu panel (keep the <ul> tag itself — its own class may be styled) so
    // critical CSS reflects what is actually visible. Their rules still load in the async full CSS, so
    // an opened dropdown is styled correctly. Depth-aware innermost-first to handle nested menus safely.
    if ( is_string($body) ) {
      // DEPTH-AWARE removal (no catastrophic-backtracking regex — a tempered-greedy pattern over a
      // 200KB+ mega-menu blows the PCRE backtrack limit). Find each OUTERMOST sub-menu <ul>, walk to
      // its matching </ul> counting nesting, and cut the whole block (which takes all nested sub-menus
      // with it in one shot). Only `sub-menu`-class dropdowns are targeted; the visible top-level nav
      // <ul> (no sub-menu class) is kept, so the nav bar stays in the critical set.
      $guard = 0;
      while ( $guard++ < 500 ) {
        if ( ! preg_match('/<ul\b[^>]*\bclass\s*=\s*("|\')[^"\']*(?:sub-menu|vs-submenu|sub_menu|dropdown-menu|mega-sub|elementor-nav-menu--dropdown)[^"\']*\1[^>]*>/i', $body, $mm, PREG_OFFSET_CAPTURE) ) { break; }
        $start = $mm[0][1];
        $j = $start + strlen($mm[0][0]);
        $depth = 1; $len = strlen($body); $end = $len;
        while ( $j < $len && $depth > 0 ) {
          $nu = stripos($body, '<ul', $j);
          $cu = stripos($body, '</ul', $j);
          if ( $cu === false ) { $end = $len; break; }
          if ( $nu !== false && $nu < $cu ) { $depth++; $j = $nu + 3; }
          else { $depth--; $j = $cu + 4; if ( $depth === 0 ) { $gt = strpos($body, '>', $cu); $end = ( $gt === false ) ? $len : $gt + 1; } }
        }
        $body = substr($body, 0, $start) . substr($body, $end);
      }
    }
    if ( ! is_string($body) || $body === '' ) { return $html; }
    if ( ! is_string($body) ) { return $html; }   // PCRE backtrack limit -> fail open
    $budget = defined('APO_CC_FOLD_BYTES') ? (int) APO_CC_FOLD_BYTES : 60000;
    if ( $budget < 8000 ) { $budget = 8000; }
    // Body fits the fold budget (possibly BECAUSE we just stripped the sub-menus) — use the STRIPPED
    // body, not the original $html, or the dropdown tokens we removed would come right back.
    if ( strlen($body) <= $budget ) { return $prefix . $body; }
    $cut = $budget;
    // (a) Never cut before the header ends — a mega-menu can be 30-40KB on its own and is 100% in
    //     the fold. Only honour it if it isn't absurdly deep.
    if ( preg_match('#</header>#i',$body,$hm,PREG_OFFSET_CAPTURE) ) {
      $he = $hm[0][1] + strlen($hm[0][0]);
      if ( $he > $cut && $he <= $budget*2 ) { $cut = $he; }
    }
    // (b) Snap FORWARD to the next builder SECTION START so we never take half a section. Clamped so
    //     one page-long container can't swallow the whole document.
    if ( preg_match_all('#<(?:section|div|header|main|article)\b[^>]*\bclass=("|\')[^"\']*(?:elementor-top-section|elementor-section\b|e-con\b|e-parent\b|wp-block-group|wp-block-cover|site-main|entry-content)[^"\']*\1#i',$body,$sm,PREG_OFFSET_CAPTURE) ) {
      foreach ( $sm[0] as $sx ) {
        if ( $sx[1] >= $cut ) { if ( $sx[1] <= $budget*1.5 ) { $cut = $sx[1]; } break; }
      }
    }
    return $prefix . substr($body,0,$cut);
  } catch ( \Throwable $e ) { return $html; }
}
function _apo_cc_sel_used( $sel, $tok ) {
  $s=trim($sel); if($s==='') return false;
  $low=strtolower($s);
  if ( strpos($low,':root')!==false || strpos($low,'html')===0 || strpos($low,'body')===0 || strpos($low,'*')===0 ) return true;
  // A3: ALWAYS keep rules for classes that JS applies AFTER load (sticky headers, dropdowns,
  // accordions, tabs, modals, lightboxes, slider runtime classes, lazyload states). These are
  // absent from the initial HTML tokens, so the purge would drop them and — with unused-CSS
  // removal on — the styled state never applies. Curated from Perfmatters' RUCSS selector skips.
  // PERFMATTERS-STYLE SAFELIST. This must contain ONLY classes that JavaScript ADDS AFTER load — they
  // are absent from the server-rendered HTML, so the token intersection can't see them and would
  // wrongly drop their rules (sticky states, slider runtime classes, lightbox DOM, toggle states).
  // It must NOT contain STRUCTURAL classes (elementor-section/container/row/column, e-con, swiper-
  // wrapper, slick-list, nav-menu, site-header, woocommerce, wp-container-...): those ARE in the
  // rendered HTML, so the normal AND-token check already keeps their USED rules — and force-keeping
  // them here matched THOUSANDS of frontend.min.css / style.css rules, which is exactly what bloated
  // our "critical" CSS to 285KB. Perfmatters' safelist is deliberately this small; that is the entire
  // reason its used-CSS fits where ours didn't. (Substring match, so keep entries specific.)
  static $keep = array(
    // lazyload (JS swaps data-src -> src and adds these)
    'lazyloaded','lazyloading','lazyload',
    // sticky (JS toggles on scroll)
    'elementor-sticky--active','elementor-sticky--effects','is-sticky','is-stuck','sticky-active','stuck',
    // entrance animations (JS reveals)
    'elementor-motion-effects','elementor-invisible','elementor-animated','aos-animate','animate__animated',
    // popups / lightboxes (JS-built DOM)
    'elementor-popup-modal','dialog-type','dialog-widget','elementor-lightbox','mfp-','pswp','fancybox','lg-outer','lb-',
    // interactive toggle STATES (JS-added; the base element is in HTML, only the -active state isn't)
    'is-active','is-open','is-visible','menu-open','nav-open','sub-menu-open','elementor-active','elementor-open',
    // slider RUNTIME states only (NOT the structural slick-/swiper- wrappers, which are in the HTML)
    'swiper-slide-active','swiper-slide-next','swiper-slide-prev','swiper-slide-visible',
    'swiper-pagination-bullet-active','slick-active','slick-current','slick-center','slick-cloned',
    'tns-slide-active','splide__slide--active','is-selected','flickity-enabled',
    // WP/theme runtime
    'ast-header-break-point','admin-bar','logged-in',
    // v6.245 — a few more JS-ADDED / JS-INSERTED states from the reference plugins (Kadence mobile-nav
    // toggle, Revolution Slider full-width forcer, Popup Maker open states). All are absent from the
    // server HTML (added/inserted by JS at runtime), so the token scan can't see them and would wrongly
    // drop their rules. Substring-specific → only ever KEEPS MORE css, never bloats structural rules.
    'dropdown-nav-special-toggle','rs-fw-forcer','pum-active','pum-open',
    // Chrome that occupies fold space (or is fixed/sticky) REGARDLESS of where it sits in the DOM —
    // markup order is not paint order, so the fold scan can legitimately miss these.
    'admin-bar','skip-link','screen-reader-text','menu-toggle','hamburger','mobile-menu','nav-menu',
    'site-header','elementor-location-header','header-sticky','scroll-to-top','back-to-top',
    // NOTE: deliberately NOT 'elementor-widget' — these are substring matches, so that single entry
    // would keep EVERY .elementor-widget-* rule in frontend.min.css and undo the whole optimisation.
  );
  foreach ( $keep as $k ) { if ( strpos($low,$k)!==false ) return true; }
  // A2 (Accelerator `sklCssSelExcl`): NEVER purge rules whose selectors are DYNAMIC — generated per
  // post / product / user / comment. Their class names are content-dependent, so a fold scan (or any
  // token scan) legitimately does not contain them even though the rule styles VISIBLE content.
  // Purging them does not just lose styling — it can make content INVISIBLE until the async CSS
  // lands (WooCommerce product grids and comment lists are the classic victims).
  // This is pure "keep more CSS": it can only ever make us optimise LESS, never break a layout.
  // SCOPED DELIBERATELY. Accelerator's list also includes a generic hex-suffix pattern
  // (.thing-a1b2c3d) and .post-123 / .product-45. We do NOT copy those: on Elementor those hashes
  // ARE present in the markup, so the token scan already keeps them correctly — while blanket-keeping
  // every hashed selector would bloat critical CSS and risk blowing the 100KB cap, which disables
  // optimisation entirely. That would trade a real regression for a theoretical fix.
  // What we DO keep is the genuinely dangerous class: selectors whose elements are NOT in the initial
  // HTML at all — user state, cart fragments, AJAX-injected comment/Woo markup. No token scan can
  // ever see those, so purging them is what makes content go INVISIBLE until the async CSS lands.
  static $dyn = array(
    '@\.(?:product_cat|product_tag|pa_|woocommerce-product-attributes-item--attribute)@i',
    '@\.(?:comment-author|bypostauthor|depth-\d)@i',
    '@\.(?:cart|checkout|woocommerce-(?:cart|checkout|account|message|error|info))@i',
    '@\.(?:logged-in|admin-bar|user-|role-)@i',
  );
  foreach ( $dyn as $re ) { if ( preg_match($re, $s) ) { return true; } }
  // ---- NORMALISE the selector BEFORE extracting class/id tokens --------------------------------
  // BUG A (was live): functional pseudo-classes INVERT or WIDEN the match, so treating their
  // arguments as required tokens is backwards. `body:not(.rtl) .hero{}` was requiring `.rtl` to be
  // present — so the rule got DROPPED on every site that does NOT use RTL, which is exactly when it
  // should apply. Same for :is()/:where()/:has()/:matches(), which are ORs, not ANDs.
  // Stripping the arguments means we simply stop constraining on them → we over-keep. Always the
  // safe direction. Two passes to handle one level of nesting, e.g. :is(.a, :not(.b)).
  $sa = $s;
  for ( $p = 0; $p < 2; $p++ ) { $sa = preg_replace('/::?[a-z-]+\([^()]*\)/i', ' ', $sa); }
  if ( ! is_string($sa) ) { return true; }
  // BUG B (was dormant): attribute VALUES contain '.' and '#'. `a[href$=".pdf"]` would be read as a
  // class named `pdf`; `a[href="#top"]` as an id named `top`. This was masked by the old blanket
  // "any selector containing [ is kept" short-circuit. Strip attribute selectors BEFORE extraction —
  // removing that short-circuit without this fix would silently start requiring a `.pdf` class.
  $had_attr = ( strpos($sa,'[') !== false );
  $sa = preg_replace('/\[[^\]]*\]/', ' ', $sa);
  if ( ! is_string($sa) ) { return true; }
  preg_match_all('/\.([a-zA-Z0-9_-]+)/',$sa,$cm);
  preg_match_all('/#([a-zA-Z0-9_-]+)/',$sa,$im);
  // Nothing to test against the DOM: pure attribute selector ([type=text], [class*="elementor-"]) or
  // an element-only selector (p, ul li). KEEP. Element-only rules are the reset/typography layer —
  // an unstyled <h1> above the fold is a guaranteed reflow when the async CSS lands, and the whole
  // layer is only a few KB. Not worth trimming; do not "optimise" this away.
  if ( empty($cm[1]) && empty($im[1]) ) { return true; }
  // Kill switch: revert to the old keep-everything-with-[ behaviour.
  if ( $had_attr && defined('APO_CC_ATTR_TIGHTEN') && ! APO_CC_ATTR_TIGHTEN ) { return true; }
  // The class/id part is a genuine AND-constraint, so evaluate it. An attribute selector layered ON
  // TOP of a class ('.footer-cta[data-x]') only NARROWS the match — it can never make the rule apply
  // to an element the class doesn't already match. So if the class isn't in the fold, the rule can't
  // style the fold, and dropping it is provably safe.
  foreach($cm[1] as $c){ if(!isset($tok['cls'][strtolower($c)])) return false; }
  foreach($im[1] as $i){ if(!isset($tok['ids'][strtolower($i)])) return false; }
  return true;
}
function _apo_cc_px( $v, $u ) { $n=(float)$v; return ( $u==='em' || $u==='rem' ) ? $n*16.0 : $n; }
function _apo_cc_media_ok( $pl, $dev ) {
  // Can this @media block possibly apply to the device bucket we're building for? Comma = OR, so we
  // keep the block if ANY part might apply. Thresholds are deliberately TIMID: the 'm' bucket is
  // UA-derived and also catches Android TABLETS (up to ~1280 CSS px), which is why we only drop
  // min-width ABOVE 768 rather than something aggressive.
  $q = trim( substr( $pl, 6 ) );
  if ( $q === '' ) { return true; }
  foreach ( explode(',', $q) as $part ) {
    $p = trim( str_replace('only ', '', $part) );
    if ( $p === '' ) { return true; }
    if ( strpos($p,'not ') !== false ) { return true; }   // negated query: don't reason about it, keep
    // A print-only part can never apply to screen paint. Not a reason to keep the block.
    if ( preg_match('/\bprint\b/',$p) && ! preg_match('/\bscreen\b/',$p) ) { continue; }
    if ( $dev === 'm' ) {
      if ( preg_match_all('/min-width\s*:\s*([0-9.]+)(px|r?em)/',$p,$mm) ) {
        $mx=0.0; foreach($mm[1] as $k=>$v){ $px=_apo_cc_px($v,$mm[2][$k]); if($px>$mx)$mx=$px; }
        if ( $mx > 768.0 ) { continue; }                  // no phone/tablet in this bucket satisfies it
      }
    } else {
      if ( preg_match_all('/max-width\s*:\s*([0-9.]+)(px|r?em)/',$p,$mm) ) {
        $mn=PHP_INT_MAX; foreach($mm[1] as $k=>$v){ $px=_apo_cc_px($v,$mm[2][$k]); if($px<$mn)$mn=$px; }
        if ( $mn < 1024.0 ) { continue; }                 // mobile-only layer; tablet blocks are KEPT
      }
    }
    return true;   // this part might apply
  }
  return false;    // no part can apply -> safe to drop the whole block
}
function _apo_cc_purge( $css, $tok, $depth=0, $dev='d' ) {
  $out=''; $i=0; $n=strlen($css); $buf=''; if($depth>5) return $css;
  while($i<$n){
    // HARD DEADLINE. This is a char-by-char PHP parser running INSIDE page render over every
    // theme+layout stylesheet (on a builder site that can be >1MB of CSS). With no bound, a cache
    // miss on a slow host stalls the request — and if the transient never persists, EVERY request
    // rebuilds and the site appears to load forever. Abort past the deadline: _apo_build_critical
    // then returns '' and the page simply keeps its CSS render-blocking (unoptimised but CORRECT).
    // A slow site is a bug; a hanging site is an outage.
    if ( ( $i & 0x3FF ) === 0 && defined('APO_CC_DEADLINE') && microtime(true) > APO_CC_DEADLINE ) { throw new \RuntimeException('apo_cc_deadline'); }
    $c=$css[$i];
    if($c==='{'){
      $d=1;$j=$i+1; while($j<$n&&$d>0){ if($css[$j]==='{')$d++; elseif($css[$j]==='}')$d--; $j++; }
      $prelude=trim($buf); $body=substr($css,$i+1,($j-1)-($i+1)); $pl=strtolower($prelude);
      if(strpos($pl,'@media')===0){
        // Device-aware prune: drop blocks that cannot apply to this bucket (and @media print).
        if ( ( ! defined('APO_CC_MEDIA_PRUNE') || APO_CC_MEDIA_PRUNE ) && ! _apo_cc_media_ok($pl,$dev) ) { $buf=''; $i=$j; continue; }
        $inner=_apo_cc_purge($body,$tok,$depth+1,$dev);
        if(trim($inner)!=='') $out.=$prelude.'{'.$inner.'}';
      } elseif(strpos($pl,'@supports')===0||strpos($pl,'@container')===0||strpos($pl,'@layer')===0){
        // @layer ADDED here: it was falling into the wholesale branch below, so an entire @layer
        // block was being kept UN-PURGED (a silent blob). It nests rules, so it must recurse.
        $inner=_apo_cc_purge($body,$tok,$depth+1,$dev);
        if(trim($inner)!=='') $out.=$prelude.'{'.$inner.'}';
      } elseif(isset($prelude[0])&&$prelude[0]==='@'){
        // @font-face / @keyframes / @page / @property: keep WHOLESALE and never purge. A missing
        // @font-face repaints the fold in a fallback font; missing @keyframes kills entrance
        // animations (elementor-invisible would leave content stuck at opacity:0).
        $out.=$prelude.'{'.$body.'}';
      } else {
        $sels=explode(',',$prelude); $keep=false;
        // ALWAYS keep any rule that DEFINES a CSS custom property, whatever its selector matches.
        // Elementor puts every global colour/font on `.elementor-kit-N{--e-global-color-*:...}`.
        // Purge that ONE rule and every var() above the fold falls back to `initial` — the whole
        // page renders unstyled. This is the single biggest catastrophic-failure mode of purging.
        // Costs a few KB. Non-negotiable.
        if ( strpos($body,'--')!==false && preg_match('/(?:^|[;{\s])--[a-z0-9_-]+\s*:/i',$body) ) { $keep=true; }
        if ( ! $keep ) { foreach($sels as $s){ if(_apo_cc_sel_used($s,$tok)){ $keep=true; break; } } }
        if($keep) $out.=$prelude.'{'.$body.'}';
      }
      $buf=''; $i=$j; continue;
    }
    $buf.=$c; $i++;
  }
  return $out;
}
function _apo_cc_abs( $css, $base_url ) {
  $base_url = explode('?',$base_url)[0];
  $dir = preg_replace('#[^/]*$#','',$base_url);
  return preg_replace_callback('/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i', function($u) use ($dir) {
    $url=trim($u[2]);
    if($url===''||strpos($url,'data:')===0||strpos($url,'http')===0||strpos($url,'//')===0) return 'url('.$u[1].$url.$u[1].')';
    $abs=$dir.$url;
    if(preg_match('#^(https?://[^/]+)(/.*)$#i',$abs,$m)){$host=$m[1];$path=$m[2];}else{$host='';$path=$abs;}
    $q=(strpos($path,'?')!==false)?substr($path,strpos($path,'?')):''; $path=explode('?',$path)[0];
    $segs=array(); foreach(explode('/',$path) as $sg){ if($sg==='..')array_pop($segs); elseif($sg!=='.'&&$sg!=='')$segs[]=$sg; }
    return 'url("'.$host.'/'.implode('/',$segs).$q.'")';
  }, $css);
}
// v7.0.11 — LOSSLESS raw-byte slim of the assembled critical CSS. Two provably layout-safe passes:
//   (1) EXACT-DUPLICATE RULE removal, keeping the LAST occurrence. The critical set is built by
//       concatenating the purged fold-CSS of several sheets (theme + elementor/frontend + per-post
//       post-*.css). Elementor emits the SAME rule across many of those per-post blocks, so the
//       concatenation carries byte-identical duplicates. Removing an earlier copy of a rule that
//       appears again LATER cannot change the computed style: the later identical rule re-applies the
//       exact same declarations at the exact same specificity, so last-wins already yields those
//       declarations, and any element matching an intervening override still ends on the later copy.
//       Therefore keep-last dedup is cascade-IDENTICAL — zero FOUC/CLS risk. At-rules (@font-face/
//       @keyframes/@media/@supports/@page/@property) are treated as atomic whole units and de-duped the
//       same way (a duplicate @font-face/@keyframes is pure waste). :root/custom-property rules dedupe
//       safely too (identical body).
//   (2) trivial `;}`->`}` (a trailing semicolon before a close brace is a no-op).
// This shrinks the RAW bytes + the RULE COUNT the browser parses — the "Style & Layout" main-thread
// cost — WITHOUT dropping any rule that isn't a byte-for-byte duplicate. It never removes a unique
// rule, so it can never thin the fold. Fail-open: on any structural anomaly return the input verbatim.
function _apo_cc_slim( $css ) {
  if ( ! is_string($css) || $css === '' ) return $css;
  try {
    $n = strlen($css); $i = 0; $buf = ''; $units = array(); // each: array(key,text)
    while ( $i < $n ) {
      if ( ( $i & 0x3FF ) === 0 && defined('APO_CC_DEADLINE') && microtime(true) > APO_CC_DEADLINE ) { return $css; }
      $c = $css[$i];
      if ( $c === '{' ) {
        // Walk the matching close brace (rules can nest inside @media/@supports).
        $d = 1; $j = $i + 1;
        while ( $j < $n && $d > 0 ) { if ( $css[$j] === '{' ) $d++; elseif ( $css[$j] === '}' ) $d--; $j++; }
        if ( $d !== 0 ) { return $css; } // unbalanced -> bail, keep original
        $prelude = trim($buf);
        $whole   = $prelude . substr($css, $i, $j - $i); // prelude{...}
        // Normalised key: collapse internal whitespace so cosmetically-different-but-identical rules
        // (rare after the upstream ws-collapse, but cheap insurance) still match. Key is used ONLY for
        // equality; the emitted text is the original $whole (byte-for-byte), so no value is rewritten.
        $key = preg_replace('/\s+/', ' ', $whole);
        $units[] = array( $key, $whole );
        $buf = ''; $i = $j; continue;
      }
      $buf .= $c; $i++;
    }
    if ( trim($buf) !== '' ) { return $css; } // trailing junk outside any rule -> bail (unexpected)
    if ( ! $units ) return $css;
    // Keep only the LAST index for each key.
    $last = array();
    foreach ( $units as $idx => $u ) { $last[$u[0]] = $idx; }
    $out = '';
    foreach ( $units as $idx => $u ) { if ( $last[$u[0]] === $idx ) { $out .= $u[1]; } }
    // Trivial `;}` -> `}` (trailing semicolon before a close brace).
    $out = str_replace(';}', '}', $out);
    // Safety: never return something LARGER, and never empty a non-empty block.
    if ( $out === '' || strlen($out) > strlen($css) ) return $css;
    return $out;
  } catch ( \Throwable $e ) { return $css; }
}
function _apo_build_critical( $html, $dev='d', $rum=null ) {
  $_apo_t0 = microtime(true);
  try {
    // Bound the whole build. APO_CC_MAX_MS can be raised/lowered via wp-config if ever needed.
    if ( ! defined('APO_CC_DEADLINE') ) {
      define('APO_CC_DEADLINE', $_apo_t0 + ( ( defined('APO_CC_MAX_MS') ? (float) APO_CC_MAX_MS : 1500.0 ) / 1000.0 ));
    }
    // Scope tokens to the FOLD, not the whole page. This is the difference between "critical CSS"
    // and "a copy of the stylesheets".
    // TOKENS. Prefer the BROWSER-MEASURED fold (rum_fold): the real elements the browser painted
    // above the fold, incl. sticky/fixed/JS-injected ones a server scan structurally cannot see.
    // UNION it with the heuristic slice — a union can only KEEP MORE CSS, never less, so it is
    // strictly the safe direction and covers anything the beacon happened to miss.
    $fold=_apo_cc_fold($html);
    $tok=_apo_cc_tokens($fold);
    $measured=false;
    if ( is_array($rum) && ! empty($rum['cls']) && count((array)$rum['cls']) >= 3 ) {
      $measured=true;
      $rum_cls = (array) $rum['cls'];
      $rum_ids = (array) ( $rum['ids'] ?? array() );
      // PRECISE mode (per-element RUCSS, Perfmatters-class): build critical from ONLY the browser-
      // MEASURED above-fold element set. That set excludes display:none content (e.g. the desktop
      // mega-menu that is hidden on mobile) which the heuristic markup slice cannot exclude — so the
      // critical CSS is DRAMATICALLY smaller and actually fits the size cap on heavy sites (measured:
      // 285KB union -> a fraction with measured-only). The purge STILL always keeps the safety floor
      // (custom properties, @font-face, @keyframes, the JS-applied keep-list, dynamic selectors), and
      // the full CSS loads async immediately after, so any element the beacon under-captured is styled
      // a few hundred ms later at worst — never a layout collapse.
      // Safety valve: if the measured set is implausibly small (beacon under-captured), UNION the
      // heuristic slice back in so we never ship a critical set that's too thin.
      $precise = ( ! defined('APO_CC_PRECISE') || APO_CC_PRECISE );
      if ( $precise && count($rum_cls) >= 15 ) {
        $tok = array( 'cls' => $rum_cls, 'ids' => $rum_ids );
        if ( function_exists('_apo_log') ) { _apo_log('INFO','auto_critical_css: PRECISE mode — building critical from the '.count($rum_cls).' browser-MEASURED above-fold classes ONLY (excludes hidden menus etc.), so it fits the cap. Safety floor + async full CSS still cover anything late.'); }
      } else {
        $tok['cls'] = $rum_cls + $tok['cls'];
        $tok['ids'] = $rum_ids + $tok['ids'];
        if ( function_exists('_apo_log') ) { _apo_log('INFO','auto_critical_css: using BROWSER-MEASURED fold ('.count($rum_cls).' classes) unioned with the heuristic slice'.( $precise ? ' (measured set too small for precise mode)' : '' ).'.'); }
      }
    }
    // v6.148 — ALWAYS union the SITE HEADER's tokens in, on EVERY path (measured/PRECISE, unioned, or
    // heuristic). PRECISE mode's measured fold excludes elements hidden on the measuring device, which
    // silently drops a DESKTOP-ONLY header top-bar (elementor-hidden-tablet/mobile) from a mobile-built
    // critical → the top-bar renders as an unstyled vertical list on desktop cold loads and then
    // collapses (measured CLS 0.73 on a heavy-fold test site). The header is always above the fold, so its CSS
    // MUST be critical. Additive-only (union), so it can never remove a rule or change layout — exactly
    // the "a union can only KEEP MORE CSS, never less" safe direction used for the RUM fold above.
    $htok = _apo_cc_header_tokens( $html );
    if ( ! empty($htok['cls']) ) { $tok['cls'] = $tok['cls'] + $htok['cls']; }
    if ( ! empty($htok['ids']) ) { $tok['ids'] = $tok['ids'] + $htok['ids']; }
    // FAIL-OPEN rung 1: a fold slice yielding almost no classes means the scan misfired (JS-rendered
    // body, exotic markup). Fall back to whole-page tokens (= the old behaviour) and let the 100KB
    // cap decide. Never ship a critical set built from a broken scan.
    // ONLY when we have NO browser measurement. If the browser measured this page, its fold is a FACT
    // and we must not dilute it back to whole-page guessing — that is what produced the 351KB blob.
    if ( ! $measured && count($tok['cls']) < 8 ) {
      if ( function_exists('_apo_log') ) { _apo_log('WARN','auto_critical_css: fold scan found only '.count($tok['cls']).' classes — falling back to WHOLE-PAGE tokens (unscoped). Critical CSS will be large and may hit the size cap.'); }
      $tok=_apo_cc_tokens($html);
    }
    // THE GUARANTEE. If this page has never been measured in a real browser, do NOT optimise it.
    // Returning '' keeps its CSS render-blocking: correct, zero layout risk, just not yet fast. The
    // first visitor's beacon measures it; every later request is optimised from FACTS, not a guess.
    if ( ! $measured && ( ! defined('APO_CC_REQUIRE_RUM') || APO_CC_REQUIRE_RUM ) ) {
      // v7.0.65 — WAIT FOR THE MEASUREMENT, BUT NEVER FOREVER. Gating on a real browser measurement is the
      // right default (an unmeasured page stays render-blocking = correct layout = zero cold CLS). But on an
      // aggressively-cached host the gate can never open: PROVEN live on WP Engine — the bare URL served
      // `X-Apo-Degraded: unmeasured` with 4 render-blocking theme sheets (115KB) while a cache-busted fetch of
      // the SAME url was fully optimised, because every purge re-opens a window where unmeasured renders get
      // cached and served back for the whole TTL. So: count unmeasured renders per URL, and after a few, stop
      // waiting and ship the HEURISTIC critical build instead (still size-capped + safety-floored + dynamic-
      // selector-protected). Normal hosts are unaffected — the measurement lands within a render or two and the
      // gate behaves exactly as before. Tune/disable: APO_CC_RUM_WAIT (0 = never wait, build immediately).
      $__wait = defined('APO_CC_RUM_WAIT') ? (int) APO_CC_RUM_WAIT : 3;
      $__n    = _apo_cc_degraded_nocache('unmeasured');
      if ( $__wait > 0 && $__n <= $__wait ) {
        if ( function_exists('_apo_log') ) { _apo_log('INFO','auto_critical_css: cc_require_rum is ON and this page is NOT YET MEASURED — keeping CSS render-blocking while we wait for the browser measurement (' . $__n . '/' . $__wait . '). After that APO stops waiting and builds the heuristic critical CSS so a cached host cannot stay render-blocking forever.'); }
        return '';
      }
      if ( function_exists('_apo_log') ) { _apo_log('WARN','auto_critical_css: still NOT MEASURED after ' . $__n . ' render(s) — the fold beacon is not coming back on this host (typical of an aggressive edge cache). Falling back to the HEURISTIC critical build so LCP is not left render-blocking forever. Set APO_CC_RUM_WAIT higher to wait longer, or 0 to always build immediately.'); }
    }
    $tpl=function_exists('get_template_directory_uri')?get_template_directory_uri():'';
    $stp=function_exists('get_stylesheet_directory_uri')?get_stylesheet_directory_uri():'';
    $crit='';
    if ( preg_match_all('/<link[^>]+href=("|\')([^"\']+\.css[^"\']*)\1[^>]*>/i',$html,$lm) ) {
      $seen=array();
      foreach ( $lm[2] as $href ) {
        if ( isset($seen[$href]) ) continue; $seen[$href]=1;
        if ( preg_match('/(font-?awesome|fontawesome|eicons|elementor-icons|dashicons|ionicons|material-icons|bootstrap-icons|themify|simple-line|icomoon|flaticon)/i',$href) ) continue;
        $abs=$href; if(strpos($abs,'//')===0)$abs='https:'.$abs; if(strpos($abs,'http')!==0)$abs=(function_exists('home_url')?home_url($abs):$abs);
        $intheme=($tpl&&strpos($abs,$tpl)!==false)||($stp&&strpos($abs,$stp)!==false);
        // Also pull critical from render-blocking LAYOUT/FRAMEWORK CSS (Elementor frontend + per-page
        // post-*.css, bootstrap, block CSS). Without these the FOLD LAYOUT (flex containers, columns,
        // grid) isn't in the critical set, so deferring them collapses the above-the-fold → FOUC/CLS.
        // Extracting their used rules is what makes universal CSS deferral SAFE.
        $islayout = (bool) preg_match('#(elementor/assets/css/frontend|elementor/css/post-|/uploads/elementor/css/|bootstrap|foundation\.min|/wp-block|wp-includes/css/dist/block|/blocks?\.min\.css|kadence|generatepress|astra|blocksy|oceanwp)#i',$abs);
        if(!$intheme && !$islayout) continue;
        $rp=preg_replace('#^https?://[^/]+#i','',$abs); $rp=explode('?',$rp)[0]; $rp=str_replace(array('..','\\'),'',$rp);
        $path=rtrim(ABSPATH,'/').'/'.ltrim($rp,'/');
        $css='';
        if(is_file($path)&&@filesize($path)<3145728){ $css=(string)@file_get_contents($path); }
        // Fallback to HTTP fetch (cached) for layout CSS that isn't locally readable (WP Engine, CDN).
        if($css===''&&function_exists('wp_remote_get')){
          $tk='apo_cc_src_'.md5($abs); $cd=function_exists('get_transient')?get_transient($tk):false;
          if(is_string($cd)){ $css=($cd==='__MISS__')?'':$cd; }
          else { $r=@wp_remote_get($abs,array('timeout'=>5,'sslverify'=>false)); $ok=(is_array($r)||is_object($r))&&!(function_exists('is_wp_error')&&is_wp_error($r)); $b=($ok&&function_exists('wp_remote_retrieve_body'))?(string)wp_remote_retrieve_body($r):''; $rc=($ok&&function_exists('wp_remote_retrieve_response_code'))?(int)wp_remote_retrieve_response_code($r):0; if($b!==''&&$rc<400&&strlen($b)<3145728){ $css=$b; if(function_exists('set_transient'))set_transient($tk,$b,43200); } else { if(function_exists('set_transient'))set_transient($tk,'__MISS__',3600); } }
        }
        if($css==='') continue;
        $u=_apo_cc_purge($css,$tok,0,$dev);
        $u=_apo_cc_abs($u,$abs);
        $crit.=$u;
      }
    }
    // Minify: strip comments + collapse whitespace. Same pair already shipping in
    // _apo_inline_small_css, so it inherits that production track record.
    $crit=preg_replace('#/\*(?!!)[\s\S]*?\*/#','',$crit);
    $crit=trim( (string) preg_replace('/\s+/',' ',$crit) );
    if ( $crit==='' ) return '';
    // SIZE SANITY CAP. "Critical" CSS is meant to be the above-the-fold subset — tens of KB. If the
    // purge hands back hundreds of KB it did not purge: it produced a COPY of the stylesheets, and
    // inlining that into every page makes the document enormous and the browser parse it all before
    // first paint. Measured on a live site: 351KB of "critical" CSS (+154KB more from inline_small_css)
    // = half a megabyte of inline CSS per request, and the page effectively never finished loading.
    // Inlining MORE bytes than we save is always a net loss, so refuse: keep the CSS render-blocking
    // (correct, just unoptimised) and say so loudly. 1.2MB was never a meaningful bound.
    // v6.79: the cap is measured on GZIPPED bytes — what the critical CSS actually costs on the wire,
    // since it ships inside the (gzipped) HTML response.
    //
    // This was the single most damaging bug in the plugin. It compared strlen() — RAW bytes — against a
    // cap of 100000. MEASURED on the test site: the extracted critical CSS is 190,406 RAW bytes, which is
    // only ~25KB GZIPPED. So a perfectly reasonable 25KB payload was refused for being "190KB", critical
    // CSS NEVER applied on this site, ALL theme/layout CSS stayed render-blocking, and we fell back to
    // mass-inlining every sheet instead (645KB raw -> 230KB HTML -> TTFB 662ms) while STILL leaving
    // style.css + jQuery blocking. Worst of both worlds: a huge document AND a blocked render.
    // For comparison, Seraphinite Accelerator on the SAME page: zero first-party render-blocking,
    // 122KB HTML, TTFB 440ms, LCP 2.2s — precisely because it inlines the critical set and defers the rest.
    // A raw guard still applies independently: even CSS that compresses well costs CSSOM parse time.
    $gzcap  = defined('APO_CC_MAX_BYTES') ? (int) APO_CC_MAX_BYTES : 51200;      // gz bytes (50KB gz)
    // RAW guard, independent of the gz cap. Tuned to 256KB deliberately: the real extracted set on the
    // test site is 190KB raw (accepted), while the 351KB-class "nothing purged" blob that a live site
    // once inlined — after which the page effectively never finished loading — is refused. CSS that
    // compresses to nothing still costs full CSSOM parse on every page, so gz alone is not a sufficient
    // bound. (test_ccsscap.php guards this: its ~370KB fixture must stay refused.)
    $rawcap = defined('APO_CC_MAX_RAW')   ? (int) APO_CC_MAX_RAW   : 262144;     // raw guard (256KB)
    $gz = function_exists('gzencode') ? strlen((string)@gzencode($crit,1)) : (int)(strlen($crit)/4);
    if ( $gz > $gzcap || strlen($crit) > $rawcap ) {
      if ( function_exists('_apo_log') ) {
        _apo_log('WARN','auto_critical_css SKIPPED: critical CSS is '.round($gz/1024).'KB gzipped ('.round(strlen($crit)/1024).'KB raw), over the '.round($gzcap/1024).'KB gz / '.round($rawcap/1024).'KB raw cap. Inlining more bytes than the deferral saves is a net loss, so the CSS stays render-blocking: the page is CORRECT, just not optimised. Raise with define(\'APO_CC_MAX_BYTES\', <gzip bytes>) — NOTE this cap is GZIPPED bytes as of v6.79 (it used to compare RAW bytes against a raw number, which refused a ~25KB-gzipped critical set for being "190KB" and silently disabled this feature on CSS-heavy sites).');
      }
      return '';
    }
    if ( function_exists('_apo_log') ) {
      _apo_log('INFO','auto_critical_css: inlining '.round($gz/1024).'KB gzipped ('.round(strlen($crit)/1024).'KB raw) of critical CSS — the render-blocking theme/layout stylesheets can now be deferred.');
    }
    // Universal safety baseline — prepended so the fold never collapses even if a rule was missed:
    // box model, media sizing, no body margin, hidden attr. Cheap, theme-agnostic, prevents the worst
    // FOUC symptoms (full-width images, width blowouts) when the full CSS is deferred.
    $base = '*,*::before,*::after{box-sizing:border-box}img,svg,video,iframe{max-width:100%;height:auto}body{margin:0}[hidden]{display:none!important}';
    // v7.0.11 — LOSSLESS slim (exact-duplicate rule removal, keep-last): shrinks the raw bytes + rule
    // count the browser parses, with zero rule loss. Gated on APO_CC_SLIM (Turbo+). Base is unique (4
    // rules) so slim only the extracted body; fail-open inside _apo_cc_slim returns $crit unchanged.
    if ( defined('APO_CC_SLIM') && APO_CC_SLIM && function_exists('_apo_cc_slim') ) {
      $before = strlen($crit); $crit = _apo_cc_slim($crit);
      if ( function_exists('_apo_log') ) { _apo_log('INFO','auto_critical_css: SLIM removed '.($before-strlen($crit)).'B of byte-identical duplicate rules ('.strlen($crit).'B raw kept).'); }
    }
    if ( function_exists('_apo_log') ) { _apo_log('INFO','auto_critical_css: built '.strlen($crit).'B in '.round((microtime(true)-$_apo_t0)*1000).'ms'); }
    return $base.$crit;
  } catch ( \Throwable $e ) {
    // Deadline hit (or any parse failure): give up on critical CSS for this page. The caller caches
    // the empty result, so we do NOT re-attempt the expensive build on every subsequent request.
    // The page keeps its CSS render-blocking: slower, but it renders. Never hang.
    if ( function_exists('_apo_log') ) {
      $ms = round((microtime(true)-$_apo_t0)*1000);
      $why = ( $e->getMessage() === 'apo_cc_deadline' )
        ? 'HIT THE '.$ms.'ms DEADLINE — this site has more CSS than can be parsed in-request. Critical CSS is SKIPPED for this page (CSS stays render-blocking; page is correct, just not optimised). Raise it with define(\'APO_CC_MAX_MS\', 3000) in wp-config.php if your host can afford it.'
        : 'failed after '.$ms.'ms: '.$e->getMessage();
      _apo_log('WARN','auto_critical_css: '.$why);
    }
    _apo_cc_degraded_nocache( $e->getMessage() === 'apo_cc_deadline' ? 'deadline' : 'error' );
    return '';
  }
}
// v7.0.64 — DEGRADED RENDERS MUST NOT BE CACHED. When the critical-CSS pass falls back (page not yet measured,
// the in-request deadline was hit, or a parse error), APO returns '' and the theme CSS correctly stays
// render-blocking — the page is right, just not optimised. The danger is an EDGE CACHE freezing that one
// unlucky render: measured live on WP Engine, the bare URL was serving a variant with NO inlined critical CSS
// and 4 render-blocking theme stylesheets (115KB, ~1.1s) under `max-age=15552000` — 180 days — while a
// cache-busted request of the SAME page returned the fully optimised HTML. Every test after that scored the
// frozen degraded copy. So on a degraded render we send no-store, which keeps the edge from storing it; the
// next request re-renders and the OPTIMISED variant is what gets cached.
// BOUNDED so a site that can never build critical CSS cannot become permanently uncacheable: after a few
// degraded renders per URL we stop suppressing and let the (slower but correct) variant cache normally.
// Kill: define('APO_NO_DEGRADED_NOCACHE', true).
if ( ! function_exists('_apo_cc_degraded_nocache') ) {
// Returns how many degraded renders this URL has had (1 = first). Callers use it to decide when to stop
// waiting for a browser measurement. Counting happens even when header-suppression is disabled or already
// spent, so the count is always meaningful; only the no-store header is bounded.
function _apo_cc_degraded_nocache( $reason = '' ) {
  $n = 0;
  try {
    if ( ! function_exists('get_transient') || ! function_exists('set_transient') ) { return 0; }
    $max = defined('APO_DEGRADED_NOCACHE_MAX') ? (int) APO_DEGRADED_NOCACHE_MAX : 4;
    $key = 'apo_ccdeg_' . substr( md5( ( $_SERVER['HTTP_HOST'] ?? '' ) . '|' . strtok( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), '?' ) ), 0, 20 );
    $n = (int) get_transient( $key ) + 1;
    set_transient( $key, $n, 21600 );      // 6h: long enough that "stop waiting" survives a cache TTL cycle
    if ( defined('APO_NO_DEGRADED_NOCACHE') && APO_NO_DEGRADED_NOCACHE ) { return $n; }
    if ( headers_sent() ) { return $n; }
    if ( $n > $max ) { return $n; }        // give up suppressing: accept the slower variant rather than never caching
    header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true );
    header( 'X-APO-Degraded: ' . preg_replace('/[^a-z0-9_-]/i','',(string)$reason), true );
    if ( function_exists('_apo_log') ) { _apo_log('WARN','degraded render (' . $reason . ') -> sent no-store so an edge cache cannot freeze this unoptimised variant (attempt ' . $n . '/' . $max . ').'); }
  } catch ( \Throwable $e ) {}
  return $n;
}}}
}
